const squadre = [
    "San Bernardo", "CincioniFc", "Juventus", "Sbronzi di Riacee",
    "Foggia", "Ac Tua", "Fully Burger", "Hello Kitty FC", "Cannoli", "Igor Miti"
];

const calendario = [
    [[0,1],[2,3],[4,5],[6,7],[8,9]],
    [[0,2],[1,4],[3,6],[5,8],[7,9]],
    [[0,3],[2,5],[1,6],[4,9],[7,8]],
    [[0,4],[3,5],[2,7],[1,8],[6,9]],
    [[0,5],[4,6],[3,8],[2,9],[1,7]],
    [[0,6],[5,7],[4,2],[3,9],[1,8]],
    [[0,7],[6,8],[5,9],[1,2],[3,4]],
    [[0,8],[7,9],[1,3],[2,6],[4,5]],
    [[0,9],[1,5],[2,8],[3,7],[4,6]]
];

let scelta = null;
let stato = caricaStato();

function creaStatoNuovo() {
    const classifica = squadre.map(nome => ({ nome: nome, g: 0, v: 0, n: 0, p: 0, pt: 0 }));
    return { giornata: 0, classifica: classifica, ultime: [], betsGiornata: {} };
}

function caricaStato() {
    const salvato = localStorage.getItem("vbucks365-stato");
    if (salvato) return JSON.parse(salvato);
    return creaStatoNuovo();
}

function salvaStato() {
    localStorage.setItem("vbucks365-stato", JSON.stringify(stato));
}

function squadraNome(i) {
    return squadre[i];
}

function forzaSquadra(i) {
    if (i === 0 || i === 1) return 3;
    if (i === 2 || i === 3) return 1;
    return 2;
}

function generaGol(forza) {
    let gol = Math.floor(Math.random() * 3);
    if (forza === 3) gol += Math.floor(Math.random() * 2);
    if (forza === 1) gol -= 1;
    return Math.max(0, gol);
}

function calcolaQuote(casa, ospite, indice) {
    const diff = forzaSquadra(casa) - forzaSquadra(ospite);
    const ritocco = indice * 0.05;
    if (diff > 0) return { q1: (1.55 + ritocco).toFixed(2), qx: (3.10 + ritocco).toFixed(2), q2: (4.10 + ritocco).toFixed(2) };
    if (diff < 0) return { q1: (4.10 + ritocco).toFixed(2), qx: (3.10 + ritocco).toFixed(2), q2: (1.55 + ritocco).toFixed(2) };
    return { q1: (2.35 + ritocco).toFixed(2), qx: (3.00 + ritocco).toFixed(2), q2: (2.35 + ritocco).toFixed(2) };
}

function esitoPartita(golCasa, golOspite) {
    if (golCasa > golOspite) return "1";
    if (golCasa < golOspite) return "2";
    return "X";
}

function controllaVittoria(sceltaUtente, esito) {
    return sceltaUtente === esito;
}

document.addEventListener("DOMContentLoaded", function() {
    renderClassifica();
    renderCalendario();
    renderUltime();
    preparaBet();
});

function preparaBet() {
    const select = document.getElementById("partita-select");
    if (!select) return;

    if (stato.giornata >= calendario.length) {
        select.innerHTML = "<option>Campionato finito</option>";
        document.getElementById("giornata-attuale").textContent = "Tutte le giornate sono state giocate.";
        document.getElementById("q1").textContent = "-";
        document.getElementById("qx").textContent = "-";
        document.getElementById("q2").textContent = "-";
        renderBetsSalvate();
        return;
    }

    document.getElementById("giornata-attuale").textContent = "Giornata " + (stato.giornata + 1) + " di " + calendario.length;
    select.innerHTML = "";

    calendario[stato.giornata].forEach(function(partita, indice) {
        const casa = squadraNome(partita[0]);
        const ospite = squadraNome(partita[1]);
        select.innerHTML += `<option value="${indice}">${casa} - ${ospite}</option>`;
    });

    select.onchange = function() {
        aggiornaQuote();
        caricaSceltaSalvata();
    };

    aggiornaQuote();
    caricaSceltaSalvata();
    renderBetsSalvate();
}

function aggiornaQuote() {
    const select = document.getElementById("partita-select");
    if (!select || stato.giornata >= calendario.length) return;

    const indice = parseInt(select.value);
    const partita = calendario[stato.giornata][indice];
    const quote = calcolaQuote(partita[0], partita[1], indice);
    document.getElementById("q1").textContent = quote.q1;
    document.getElementById("qx").textContent = quote.qx;
    document.getElementById("q2").textContent = quote.q2;
}

function caricaSceltaSalvata() {
    const select = document.getElementById("partita-select");
    if (!select) return;

    const indice = select.value;
    const betSalvata = stato.betsGiornata[indice];
    scelta = betSalvata ? betSalvata.scelta : null;

    document.querySelectorAll(".quote button").forEach(function(btn) {
        btn.classList.remove("selezionato");
        if (scelta && btn.textContent.trim().startsWith(scelta)) {
            btn.classList.add("selezionato");
        }
    });
}

function selezionaEsito(bottone, valore) {
    document.querySelectorAll(".quote button").forEach(btn => btn.classList.remove("selezionato"));
    bottone.classList.add("selezionato");
    scelta = valore;
}

function salvaScommessa() {
    const select = document.getElementById("partita-select");
    if (!select || stato.giornata >= calendario.length) return;
    if (!scelta) {
        alert("Prima scegli 1, X oppure 2.");
        return;
    }

    const indice = select.value;
    const partita = calendario[stato.giornata][indice];
    const quote = calcolaQuote(partita[0], partita[1], parseInt(indice));
    let quotaScelta = quote.q1;
    if (scelta === "X") quotaScelta = quote.qx;
    if (scelta === "2") quotaScelta = quote.q2;

    stato.betsGiornata[indice] = {
        scelta: scelta,
        quota: quotaScelta,
        casa: squadraNome(partita[0]),
        ospite: squadraNome(partita[1])
    };

    salvaStato();
    renderBetsSalvate();
    document.getElementById("risultato").textContent = "Scommessa salvata. Puoi sceglierne un'altra della stessa giornata.";
    document.getElementById("risultato").className = "info";
}

function renderBetsSalvate() {
    const box = document.getElementById("bet-salvate");
    if (!box) return;

    const bets = Object.values(stato.betsGiornata || {});
    if (bets.length === 0) {
        box.innerHTML = "<p class='testo-piccolo'>Nessuna scommessa salvata per questa giornata.</p>";
        return;
    }

    box.innerHTML = "<b>Scommesse salvate:</b>";
    bets.forEach(function(bet) {
        box.innerHTML += `<div class="bet-riga">${bet.casa} - ${bet.ospite}: <b>${bet.scelta}</b> quota ${bet.quota}</div>`;
    });
}

function giocaGiornata() {
    if (stato.giornata >= calendario.length) {
        alert("Il campionato è già finito!");
        return;
    }

    if (Object.keys(stato.betsGiornata).length === 0) {
        alert("Salva almeno una scommessa prima di giocare la giornata.");
        return;
    }

    const partiteGiornata = calendario[stato.giornata];
    const risultatiGiornata = [];
    let vinte = 0;
    let perse = 0;

    partiteGiornata.forEach(function(partita, indice) {
        const casa = partita[0];
        const ospite = partita[1];
        const golCasa = generaGol(forzaSquadra(casa));
        const golOspite = generaGol(forzaSquadra(ospite));
        const esito = esitoPartita(golCasa, golOspite);
        const bet = stato.betsGiornata[indice];
        const vinta = bet ? controllaVittoria(bet.scelta, esito) : false;

        if (bet && vinta) vinte++;
        if (bet && !vinta) perse++;

        aggiornaClassifica(casa, ospite, golCasa, golOspite);

        risultatiGiornata.push({
            giornata: stato.giornata + 1,
            casa: squadraNome(casa),
            ospite: squadraNome(ospite),
            golCasa: golCasa,
            golOspite: golOspite,
            scelta: bet ? bet.scelta : "",
            quota: bet ? bet.quota : "",
            vinta: vinta,
            avevaBet: bet ? true : false
        });
    });

    stato.ultime = risultatiGiornata;
    stato.giornata++;
    stato.betsGiornata = {};
    salvaStato();

    scelta = null;
    mostraRisultato(vinte, perse);
    renderClassifica();
    renderUltime();
    renderCalendario();
    preparaBet();
}

function aggiornaClassifica(casa, ospite, golCasa, golOspite) {
    stato.classifica[casa].g++;
    stato.classifica[ospite].g++;

    if (golCasa > golOspite) {
        stato.classifica[casa].v++;
        stato.classifica[ospite].p++;
        stato.classifica[casa].pt += 3;
    } else if (golCasa < golOspite) {
        stato.classifica[ospite].v++;
        stato.classifica[casa].p++;
        stato.classifica[ospite].pt += 3;
    } else {
        stato.classifica[casa].n++;
        stato.classifica[ospite].n++;
        stato.classifica[casa].pt++;
        stato.classifica[ospite].pt++;
    }
}

function mostraRisultato(vinte, perse) {
    const box = document.getElementById("risultato");
    if (!box) return;
    box.className = vinte > 0 ? "vinto" : "perso";
    box.textContent = "Giornata giocata: " + vinte + " bet vinte e " + perse + " perse.";
}

function renderClassifica() {
    const corpo = document.getElementById("corpo-classifica");
    if (!corpo) return;

    const ordine = [...stato.classifica].sort((a, b) => b.pt - a.pt || b.v - a.v);
    corpo.innerHTML = "";
    ordine.forEach(function(sq, i) {
        corpo.innerHTML += `
            <tr>
                <td>${i + 1}</td>
                <td>${sq.nome}</td>
                <td>${sq.g}</td>
                <td>${sq.v}</td>
                <td>${sq.n}</td>
                <td>${sq.p}</td>
                <td><b>${sq.pt}</b></td>
            </tr>`;
    });
}

function renderUltime() {
    const lista = document.getElementById("lista-ultime");
    if (!lista) return;

    if (stato.ultime.length === 0) {
        lista.innerHTML = "<p class='testo-piccolo'>Nessuna giornata giocata.</p>";
        return;
    }

    lista.innerHTML = `<p class='testo-piccolo'>Giornata ${stato.ultime[0].giornata}</p>`;
    stato.ultime.forEach(function(p) {
        let badge = "<span class='badge neutro'>nessuna bet</span>";
        if (p.avevaBet && p.vinta) badge = `<span class='badge ok'>bet ${p.scelta}: vinta</span>`;
        if (p.avevaBet && !p.vinta) badge = `<span class='badge no'>bet ${p.scelta}: persa</span>`;

        lista.innerHTML += `
            <div class="partita">
                <span>${p.casa} ${p.golCasa} - ${p.golOspite} ${p.ospite}</span>
                ${badge}
            </div>`;
    });
}

function renderCalendario() {
    const lista = document.getElementById("lista-calendario");
    if (!lista) return;

    lista.innerHTML = "";
    calendario.forEach(function(giornata, i) {
        const giocata = i < stato.giornata ? " giocata" : "";
        lista.innerHTML += `<h3 class="titolo-giornata">Giornata ${i + 1}${giocata ? " - giocata" : ""}</h3>`;
        giornata.forEach(function(partita) {
            lista.innerHTML += `<div class="partita calendario-riga">${squadraNome(partita[0])} - ${squadraNome(partita[1])}</div>`;
        });
    });
}

function ricominciaCampionato() {
    if (!confirm("Vuoi ricominciare il campionato da zero?")) return;
    stato = creaStatoNuovo();
    scelta = null;
    salvaStato();
    renderClassifica();
    renderUltime();
    renderCalendario();
    preparaBet();
    const box = document.getElementById("risultato");
    if (box) {
        box.textContent = "Campionato ricominciato.";
        box.className = "info";
    }
}
