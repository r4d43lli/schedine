// LISTA DELLE SQUADRE
let squadre = [
    "San Bernardo", "CincioniFc", "Juventus", "Sbronzi di Riacee",
    "Foggia", "Ac Tua", "Fully Burger", "Hello Kitty FC", "Cannoli", "Igor Miti"
];

// CALENDARIO: ogni numero indica una squadra della lista sopra
let calendario = [
    [[0,1],[2,3],[4,5],[6,7],[8,9]],
    [[0,2],[1,4],[3,6],[5,8],[7,9]],
    [[0,3],[2,5],[1,6],[4,9],[7,8]],
    [[0,4],[3,5],[2,7],[1,8],[6,9]],
    [[0,5],[4,6],[3,8],[2,9],[1,7]],
    [[0,6],[5,7],[4,2],[3,9],[1,8]],
    [[0,7],[6,8],[5,9],[1,2],[3,4]],
    [[0,8],[7,9],[1,3],[2,6],[4,5]],
    [[0,9],[1,5],[2,8],[3,7],[4,6]]
];

let giornata = 0;
let classifica = [];
let ultimePartite = [];
let scommesse = [];
let scelta = "";

// CREA LA CLASSIFICA INIZIALE
for (let i = 0; i < squadre.length; i++) {
    classifica.push({
        nome: squadre[i],
        giocate: 0,
        vinte: 0,
        pari: 0,
        perse: 0,
        punti: 0
    });
}

function nomeSquadra(numero) {
    return squadre[numero];
}

function forzaSquadra(numero) {
    if (numero == 0 || numero == 1) return 3;
    if (numero == 2 || numero == 3) return 1;
    return 2;
}

function generaGol(forza) {
    let gol = Math.floor(Math.random() * 3);
    if (forza == 3) gol = gol + Math.floor(Math.random() * 2);
    if (forza == 1) gol = gol - 1;
    if (gol < 0) gol = 0;
    return gol;
}

function calcolaQuote(casa, ospite) {
    let differenza = forzaSquadra(casa) - forzaSquadra(ospite);

    if (differenza > 0) return ["1.60", "3.20", "4.50"];
    if (differenza < 0) return ["4.50", "3.20", "1.60"];
    return ["2.40", "3.00", "2.40"];
}

function risultatoPartita(golCasa, golOspite) {
    if (golCasa > golOspite) return "1";
    if (golCasa < golOspite) return "2";
    return "X";
}

function preparaScommesse() {
    let menu = document.getElementById("partita-select");
    if (menu == null) return;

    let testoGiornata = document.getElementById("giornata-attuale");

    if (giornata >= calendario.length) {
        menu.innerHTML = "<option>Campionato finito</option>";
        testoGiornata.innerHTML = "Tutte le giornate sono state giocate.";
        document.getElementById("q1").innerHTML = "-";
        document.getElementById("qx").innerHTML = "-";
        document.getElementById("q2").innerHTML = "-";
        return;
    }

    testoGiornata.innerHTML = "Giornata " + (giornata + 1) + " di " + calendario.length;
    menu.innerHTML = "";

    let partite = calendario[giornata];
    for (let i = 0; i < partite.length; i++) {
        let casa = partite[i][0];
        let ospite = partite[i][1];
        menu.innerHTML += "<option value='" + i + "'>" + nomeSquadra(casa) + " - " + nomeSquadra(ospite) + "</option>";
    }

    menu.onchange = function() {
        scelta = "";
        togliSelezione();
        aggiornaQuote();
    };

    scelta = "";
    togliSelezione();
    aggiornaQuote();
}

function aggiornaQuote() {
    let menu = document.getElementById("partita-select");
    if (menu == null) return;
    if (giornata >= calendario.length) return;

    let numeroPartita = parseInt(menu.value);
    let partita = calendario[giornata][numeroPartita];
    let quote = calcolaQuote(partita[0], partita[1]);

    document.getElementById("q1").innerHTML = quote[0];
    document.getElementById("qx").innerHTML = quote[1];
    document.getElementById("q2").innerHTML = quote[2];
}

function togliSelezione() {
    let bottoni = document.querySelectorAll(".quote button");
    for (let i = 0; i < bottoni.length; i++) {
        bottoni[i].classList.remove("selezionato");
    }
}

function selezionaEsito(bottone, valore) {
    togliSelezione();
    bottone.classList.add("selezionato");
    scelta = valore;
}

function salvaScommessa() {
    if (giornata >= calendario.length) {
        alert("Il campionato è finito!");
        return;
    }

    if (scelta == "") {
        alert("Scegli prima 1, X oppure 2.");
        return;
    }

    let menu = document.getElementById("partita-select");
    let numeroPartita = parseInt(menu.value);
    let giaPresente = false;

    for (let i = 0; i < scommesse.length; i++) {
        if (scommesse[i].partita == numeroPartita) {
            scommesse[i].scelta = scelta;
            giaPresente = true;
        }
    }

    if (giaPresente == false) {
        scommesse.push({ partita: numeroPartita, scelta: scelta });
    }

    scelta = "";
    togliSelezione();
    mostraScommesse();
    alert("Scommessa salvata!");
}

function mostraScommesse() {
    let box = document.getElementById("lista-bet");
    if (box == null) return;

    if (scommesse.length == 0) {
        box.innerHTML = "<p class='testo-piccolo'>Nessuna scommessa salvata.</p>";
        return;
    }

    box.innerHTML = "<b>Scommesse salvate:</b>";
    let partite = calendario[giornata];

    for (let i = 0; i < scommesse.length; i++) {
        let partita = partite[scommesse[i].partita];
        box.innerHTML += "<div class='bet-riga'><span>" + nomeSquadra(partita[0]) + " - " + nomeSquadra(partita[1]) + "</span><span class='badge neutro'>" + scommesse[i].scelta + "</span></div>";
    }
}

function giocaGiornata() {
    if (giornata >= calendario.length) {
        alert("Il campionato è finito!");
        return;
    }

    if (scommesse.length == 0) {
        alert("Salva almeno una scommessa prima di giocare.");
        return;
    }

    let partite = calendario[giornata];
    ultimePartite = [];
    let vinte = 0;

    for (let i = 0; i < partite.length; i++) {
        let casa = partite[i][0];
        let ospite = partite[i][1];
        let golCasa = generaGol(forzaSquadra(casa));
        let golOspite = generaGol(forzaSquadra(ospite));
        let esito = risultatoPartita(golCasa, golOspite);

        aggiornaClassifica(casa, ospite, golCasa, golOspite);

        let sceltaTrovata = "";
        let eraScommessa = false;
        let vinta = false;

        for (let j = 0; j < scommesse.length; j++) {
            if (scommesse[j].partita == i) {
                sceltaTrovata = scommesse[j].scelta;
                eraScommessa = true;
                if (sceltaTrovata == esito) {
                    vinta = true;
                    vinte++;
                }
            }
        }

        ultimePartite.push({
            giornata: giornata + 1,
            casa: nomeSquadra(casa),
            ospite: nomeSquadra(ospite),
            golCasa: golCasa,
            golOspite: golOspite,
            scelta: sceltaTrovata,
            eraScommessa: eraScommessa,
            vinta: vinta
        });
    }

    let totale = scommesse.length;
    giornata++;
    scommesse = [];
    scelta = "";

    mostraRisultato(vinte, totale);
    renderClassifica();
    renderUltime();
    renderCalendario();
    preparaScommesse();
    mostraScommesse();
}

function aggiornaClassifica(casa, ospite, golCasa, golOspite) {
    classifica[casa].giocate++;
    classifica[ospite].giocate++;

    if (golCasa > golOspite) {
        classifica[casa].vinte++;
        classifica[ospite].perse++;
        classifica[casa].punti += 3;
    } else if (golCasa < golOspite) {
        classifica[ospite].vinte++;
        classifica[casa].perse++;
        classifica[ospite].punti += 3;
    } else {
        classifica[casa].pari++;
        classifica[ospite].pari++;
        classifica[casa].punti++;
        classifica[ospite].punti++;
    }
}

function mostraRisultato(vinte, totale) {
    let box = document.getElementById("risultato");
    if (box == null) return;

    box.style.display = "block";
    box.innerHTML = "Hai vinto " + vinte + " scommesse su " + totale + ".";
}

function renderClassifica() {
    let corpo = document.getElementById("corpo-classifica");
    if (corpo == null) return;

    let ordinata = [];
    for (let i = 0; i < classifica.length; i++) {
        ordinata.push(classifica[i]);
    }

    ordinata.sort(function(a, b) {
        return b.punti - a.punti;
    });

    corpo.innerHTML = "";
    for (let i = 0; i < ordinata.length; i++) {
        corpo.innerHTML += "<tr><td>" + (i + 1) + "</td><td>" + ordinata[i].nome + "</td><td>" + ordinata[i].giocate + "</td><td>" + ordinata[i].vinte + "</td><td>" + ordinata[i].pari + "</td><td>" + ordinata[i].perse + "</td><td><b>" + ordinata[i].punti + "</b></td></tr>";
    }
}

function renderUltime() {
    let lista = document.getElementById("lista-ultime");
    if (lista == null) return;

    if (ultimePartite.length == 0) {
        lista.innerHTML = "<p class='testo-piccolo'>Nessuna giornata giocata.</p>";
        return;
    }

    lista.innerHTML = "<p class='testo-piccolo'>Giornata " + ultimePartite[0].giornata + "</p>";

    for (let i = 0; i < ultimePartite.length; i++) {
        let p = ultimePartite[i];
        let badge = "<span class='badge neutro'>nessuna bet</span>";

        if (p.eraScommessa == true && p.vinta == true) {
            badge = "<span class='badge ok'>bet " + p.scelta + ": vinta</span>";
        }

        if (p.eraScommessa == true && p.vinta == false) {
            badge = "<span class='badge no'>bet " + p.scelta + ": persa</span>";
        }

        lista.innerHTML += "<div class='partita'><span>" + p.casa + " " + p.golCasa + " - " + p.golOspite + " " + p.ospite + "</span>" + badge + "</div>";
    }
}

function renderCalendario() {
    let lista = document.getElementById("lista-calendario");
    if (lista == null) return;

    lista.innerHTML = "";

    for (let i = 0; i < calendario.length; i++) {
        let stato = "da giocare";
        if (i < giornata) stato = "giocata";
        if (i == giornata) stato = "prossima";

        lista.innerHTML += "<h3>Giornata " + (i + 1) + " - " + stato + "</h3>";

        for (let j = 0; j < calendario[i].length; j++) {
            let partita = calendario[i][j];
            lista.innerHTML += "<div class='match-card'><span>" + nomeSquadra(partita[0]) + " - " + nomeSquadra(partita[1]) + "</span><span class='badge neutro'>" + stato + "</span></div>";
        }
    }
}

function resetCampionato() {
    if (confirm("Vuoi ricominciare il campionato?")) {
        giornata = 0;
        ultimePartite = [];
        scommesse = [];
        scelta = "";
        classifica = [];

        for (let i = 0; i < squadre.length; i++) {
            classifica.push({ nome: squadre[i], giocate: 0, vinte: 0, pari: 0, perse: 0, punti: 0 });
        }

        renderClassifica();
        renderUltime();
        renderCalendario();
        preparaScommesse();
        mostraScommesse();
    }
}

// AVVIO DEL SITO
renderClassifica();
renderUltime();
renderCalendario();
preparaScommesse();
mostraScommesse();
