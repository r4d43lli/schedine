// DATI PRINCIPALI
const nomiSquadre = [
    "San Bernardo", "CincioniFc", "Juventus", "Sbronzi di Riacee",
    "Foggia", "Ac Tua", "Fully Burger", "Hello Kitty FC", "Cannoli", "Igor Miti"
];

// Ogni giornata ha 5 partite
const calendarioCampionato = [
    [[0,1],[2,3],[4,5],[6,7],[8,9]],
    [[0,2],[1,4],[3,6],[5,8],[7,9]],
    [[0,3],[2,5],[1,6],[4,9],[7,8]],
    [[0,4],[3,5],[2,7],[1,8],[6,9]],
    [[0,5],[4,6],[3,8],[2,9],[1,7]],
    [[0,6],[5,7],[4,2],[3,9],[1,8]],
    [[0,7],[6,8],[5,9],[1,2],[3,4]],
    [[0,8],[7,9],[1,3],[2,6],[4,5]],
    [[0,9],[1,5],[2,8],[3,7],[4,6]]
];

let sceltaScommessa = null;
let datiCampionato = caricaStato();

function creaStatoNuovo() {
    const classificaIniziale = nomiSquadre.map(function(nome) {
        return { nome: nome, g: 0, v: 0, n: 0, p: 0, pt: 0 };
    });

    return {
        giornata: 0,
        classifica: classificaIniziale,
        ultime: [],
        scommesse: []
    };
}

function caricaStato() {
    const datiSalvati = localStorage.getItem("vbucks365-datiCampionato");

    if (datiSalvati) {
        try {
            const dati = JSON.parse(datiSalvati);
            if (!dati.scommesse) dati.scommesse = [];
            if (!dati.ultime) dati.ultime = [];
            return dati;
        } catch (errore) {
            return creaStatoNuovo();
        }
    }

    return creaStatoNuovo();
}

function salvaDati() {
    localStorage.setItem("vbucks365-datiCampionato", JSON.stringify(datiCampionato));
}

function nomeSquadra(indice) {
    return nomiSquadre[indice];
}

function forzaSquadra(indice) {
    if (indice === 0 || indice === 1) return 3;
    if (indice === 2 || indice === 3) return 1;
    return 2;
}

function generaGol(forza) {
    let gol = Math.floor(Math.random() * 3);
    if (forza === 3) gol += Math.floor(Math.random() * 2);
    if (forza === 1) gol -= 1;
    return Math.max(0, gol);
}

function calcolaQuote(casa, ospite) {
    const differenza = forzaSquadra(casa) - forzaSquadra(ospite);

    if (differenza > 0) {
        return { q1: "1.60", qx: "3.20", q2: "4.50" };
    }

    if (differenza < 0) {
        return { q1: "4.50", qx: "3.20", q2: "1.60" };
    }

    return { q1: "2.40", qx: "3.00", q2: "2.40" };
}

function esitoPartita(golCasa, golOspite) {
    if (golCasa > golOspite) return "1";
    if (golCasa < golOspite) return "2";
    return "X";
}

function partitaGiaScommessa(indicePartita) {
    return datiCampionato.scommesse.find(function(scommessa) {
        return scommessa.indicePartita === indicePartita;
    });
}

document.addEventListener("DOMContentLoaded", function() {
    renderClassifica();
    renderCalendario();
    renderUltime();
    preparaScommesse();
    renderScommesseSalvate();
});

function preparaScommesse() {
    const menuPartite = document.getElementById("partita-select");
    if (!menuPartite) return;

    if (datiCampionato.giornata >= calendarioCampionato.length) {
        menuPartite.innerHTML = "<option>Campionato finito</option>";
        const scrittaGiornata = document.getElementById("giornata-attuale");
        if (scrittaGiornata) scrittaGiornata.textContent = "Tutte le giornate sono state giocate.";
        aggiornaQuoteVuote();
        return;
    }

    const scrittaGiornata = document.getElementById("giornata-attuale");
    if (scrittaGiornata) {
        scrittaGiornata.textContent = "Giornata " + (datiCampionato.giornata + 1) + " di " + calendarioCampionato.length;
    }

    menuPartite.innerHTML = "";
    const partiteGiornata = calendarioCampionato[datiCampionato.giornata];

    partiteGiornata.forEach(function(partita, indice) {
        menuPartite.innerHTML += `<option value="${indice}">${nomeSquadra(partita[0])} - ${nomeSquadra(partita[1])}</option>`;
    });

    menuPartite.onchange = function() {
        sceltaScommessa = null;
        togliSelezioneBottoni();
        aggiornaQuote();
    };

    sceltaScommessa = null;
    togliSelezioneBottoni();
    aggiornaQuote();
}

function aggiornaQuoteVuote() {
    const q1 = document.getElementById("q1");
    const qx = document.getElementById("qx");
    const q2 = document.getElementById("q2");

    if (q1) q1.textContent = "-";
    if (qx) qx.textContent = "-";
    if (q2) q2.textContent = "-";
}

function aggiornaQuote() {
    const menuPartite = document.getElementById("partita-select");
    if (!menuPartite) return;
    if (datiCampionato.giornata >= calendarioCampionato.length) return;

    const indicePartita = parseInt(menuPartite.value);
    const partita = calendarioCampionato[datiCampionato.giornata][indicePartita];
    if (!partita) return;

    const quote = calcolaQuote(partita[0], partita[1]);

    document.getElementById("q1").textContent = quote.q1;
    document.getElementById("qx").textContent = quote.qx;
    document.getElementById("q2").textContent = quote.q2;
}

function togliSelezioneBottoni() {
    document.querySelectorAll(".quote button").forEach(function(bottone) {
        bottone.classList.remove("selezionato");
    });
}

function selezionaEsito(bottone, valore) {
    togliSelezioneBottoni();
    bottone.classList.add("selezionato");
    sceltaScommessa = valore;
}

function salvaScommessa() {
    if (datiCampionato.giornata >= calendarioCampionato.length) {
        alert("Il campionato è finito!");
        return;
    }

    const menuPartite = document.getElementById("partita-select");
    if (!menuPartite) return;

    const indicePartita = parseInt(menuPartite.value);
    if (isNaN(indicePartita)) {
        alert("Scegli una partita.");
        return;
    }

    if (!sceltaScommessa) {
        alert("Prima scegli 1, X oppure 2.");
        return;
    }

    const scommessaEsistente = partitaGiaScommessa(indicePartita);

    if (scommessaEsistente) {
        scommessaEsistente.sceltaScommessa = sceltaScommessa;
    } else {
        datiCampionato.scommesse.push({
            indicePartita: indicePartita,
            sceltaScommessa: sceltaScommessa
        });
    }

    salvaDati();
    renderScommesseSalvate();

    sceltaScommessa = null;
    togliSelezioneBottoni();
    alert("Scommessa salvata!");
}

function renderScommesseSalvate() {
    const box = document.getElementById("lista-bet");
    if (!box) return;

    if (datiCampionato.scommesse.length === 0) {
        box.innerHTML = "<p class='testo-piccolo'>Nessuna scommessa salvata.</p>";
        return;
    }

    box.innerHTML = "<b>Scommesse salvate:</b>";

    datiCampionato.scommesse.forEach(function(scommessa) {
        const giornataCorrente = calendarioCampionato[datiCampionato.giornata];
        if (!giornataCorrente) return;

        const partita = giornataCorrente[scommessa.indicePartita];
        if (!partita) return;

        box.innerHTML += `
            <div class="bet-riga">
                <span>${nomeSquadra(partita[0])} - ${nomeSquadra(partita[1])}</span>
                <span class="badge neutro">${scommessa.sceltaScommessa}</span>
            </div>`;
    });
}

function giocaGiornata() {
    if (datiCampionato.giornata >= calendarioCampionato.length) {
        alert("Il campionato è già finito!");
        return;
    }

    if (datiCampionato.scommesse.length === 0) {
        alert("Prima salva almeno una scommessa.");
        return;
    }

    const partiteGiornata = calendarioCampionato[datiCampionato.giornata];
    const risultatiGiornata = [];
    let numeroVinte = 0;

    partiteGiornata.forEach(function(partita, indice) {
        const casa = partita[0];
        const ospite = partita[1];
        const golCasa = generaGol(forzaSquadra(casa));
        const golOspite = generaGol(forzaSquadra(ospite));
        const esito = esitoPartita(golCasa, golOspite);

        aggiornaClassifica(casa, ospite, golCasa, golOspite);

        const scommessa = datiCampionato.scommesse.find(function(bet) {
            return bet.indicePartita === indice;
        });

        let vinta = false;
        if (scommessa && scommessa.sceltaScommessa === esito) {
            vinta = true;
            numeroVinte++;
        }

        risultatiGiornata.push({
            giornata: datiCampionato.giornata + 1,
            casa: nomeSquadra(casa),
            ospite: nomeSquadra(ospite),
            golCasa: golCasa,
            golOspite: golOspite,
            sceltaScommessa: scommessa ? scommessa.sceltaScommessa : "",
            vinta: vinta,
            eraLaBet: scommessa ? true : false
        });
    });

    const numeroTotaleBet = risultatiGiornata.filter(function(partita) {
        return partita.eraLaBet;
    }).length;

    datiCampionato.ultime = risultatiGiornata;
    datiCampionato.giornata++;
    datiCampionato.scommesse = [];
    salvaDati();

    mostraRisultato(numeroVinte, numeroTotaleBet);
    sceltaScommessa = null;
    togliSelezioneBottoni();
    renderClassifica();
    renderUltime();
    renderCalendario();
    preparaScommesse();
    renderScommesseSalvate();
}

function aggiornaClassifica(casa, ospite, golCasa, golOspite) {
    datiCampionato.classifica[casa].g++;
    datiCampionato.classifica[ospite].g++;

    if (golCasa > golOspite) {
        datiCampionato.classifica[casa].v++;
        datiCampionato.classifica[ospite].p++;
        datiCampionato.classifica[casa].pt += 3;
    } else if (golCasa < golOspite) {
        datiCampionato.classifica[ospite].v++;
        datiCampionato.classifica[casa].p++;
        datiCampionato.classifica[ospite].pt += 3;
    } else {
        datiCampionato.classifica[casa].n++;
        datiCampionato.classifica[ospite].n++;
        datiCampionato.classifica[casa].pt++;
        datiCampionato.classifica[ospite].pt++;
    }
}

function mostraRisultato(vinte, totali) {
    const box = document.getElementById("risultato");
    if (!box) return;

    box.className = vinte > 0 ? "vinto" : "perso";
    box.textContent = "Hai vinto " + vinte + " scommesse su " + totali + ".";
}

function renderClassifica() {
    const corpo = document.getElementById("corpo-classifica");
    if (!corpo) return;

    const ordine = [...datiCampionato.classifica].sort(function(a, b) {
        return b.pt - a.pt || b.v - a.v || a.nome.localeCompare(b.nome);
    });

    corpo.innerHTML = "";

    ordine.forEach(function(squadra, indice) {
        corpo.innerHTML += `
            <tr>
                <td>${indice + 1}</td>
                <td>${squadra.nome}</td>
                <td>${squadra.g}</td>
                <td>${squadra.v}</td>
                <td>${squadra.n}</td>
                <td>${squadra.p}</td>
                <td><b>${squadra.pt}</b></td>
            </tr>`;
    });
}

function renderUltime() {
    const lista = document.getElementById("lista-ultime");
    if (!lista) return;

    if (datiCampionato.ultime.length === 0) {
        lista.innerHTML = "<p class='testo-piccolo'>Nessuna giornata giocata.</p>";
        return;
    }

    lista.innerHTML = `<p class='testo-piccolo'>Giornata ${datiCampionato.ultime[0].giornata}</p>`;

    datiCampionato.ultime.forEach(function(partita) {
        let badge = "<span class='badge neutro'>nessuna bet</span>";

        if (partita.eraLaBet && partita.vinta) {
            badge = `<span class='badge ok'>bet ${partita.sceltaScommessa}: vinta</span>`;
        }

        if (partita.eraLaBet && !partita.vinta) {
            badge = `<span class='badge no'>bet ${partita.sceltaScommessa}: persa</span>`;
        }

        lista.innerHTML += `
            <div class="partita">
                <span>${partita.casa} ${partita.golCasa} - ${partita.golOspite} ${partita.ospite}</span>
                ${badge}
            </div>`;
    });
}

function renderCalendario() {
    const lista = document.getElementById("lista-calendario");
    if (!lista) return;

    lista.innerHTML = "";

    calendarioCampionato.forEach(function(giornata, numero) {
        let statoGiornata = "da giocare";
        if (numero < datiCampionato.giornata) statoGiornata = "giocata";
        if (numero === datiCampionato.giornata) statoGiornata = "prossima";

        lista.innerHTML += `<h3>Giornata ${numero + 1} - ${statoGiornata}</h3>`;

        giornata.forEach(function(partita) {
            lista.innerHTML += `
                <div class="match-card">
                    <span>${nomeSquadra(partita[0])} - ${nomeSquadra(partita[1])}</span>
                    <span class="badge neutro">${statoGiornata}</span>
                </div>`;
        });
    });
}

function resetCampionato() {
    if (confirm("Vuoi ricominciare il campionato da zero?")) {
        datiCampionato = creaStatoNuovo();
        sceltaScommessa = null;
        salvaDati();
        location.reload();
    }
}
